## v1.0.0-beta.2
- Added support for [Enchantedbookenabler](https://modrinth.com/datapack/enchantedbookenabler-datapack)

## v1.0.0-beta.1
This is something I've been pushing for a really long time but always wished I'd have the motivation to finally have 100% of vanilla book textured with unique textures for each level. The day has come, no more repeated textures and everything should be distinguishable

That say, I present you the fist beta for xali's Enchanted Books v1 The first version was 4 years ago and a lot happened between then and not, but it is finally here.

Some of you might have been using it for a while now, so what changed?

- Added textures for all mace enchants
- New textures for Depth Strider
- New textures for Piercing
- New textures for Blast Protection
- New textures for Feather Falling
- New textures for Lure
- New textures for Sweeping Edge
- Tweak to Protection
- Tweak to Thorn
- Tweak to Soul Speed
  
There is some textures i'd like to tweak, but not much. Also this was made using 25w04a and there might be some issues with older mods, but if you see anything, let me know.
